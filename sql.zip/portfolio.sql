
CREATE TABLE `author` (
  `id` int NOT NULL AUTO_INCREMENT,
  `authorName` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `psw` varchar(50) DEFAULT NULL,
  `avatarPath` varchar(200) DEFAULT NULL,
  `functionName` varchar(45) DEFAULT NULL,
  `story` text,
  PRIMARY KEY (`id`)
);



CREATE TABLE `document` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `subtitle` varchar(55) DEFAULT NULL,
  `docdesc` text,
  `download` varchar(10) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `filePath` varchar(200) DEFAULT NULL,
  `imagePath` varchar(200) DEFAULT NULL,
  `content` text,
  `author` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `author` (`author`),
  CONSTRAINT `document_ibfk_1` FOREIGN KEY (`author`) REFERENCES `author` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
);
